select student_id, round(avg(value),2) as avg_mark
from mark
having avg(value) >80
group by student_id
order by avg_mark;