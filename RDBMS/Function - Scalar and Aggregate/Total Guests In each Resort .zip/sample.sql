select resortID, (sum(adultCount)+sum(childCount)) as "Total Guest"
from booking
group by resortID
having (sum(adultCount)+sum(childCount))<=10
order by resortID;