select max(fare) as Maximum_Amount
from tickets;
