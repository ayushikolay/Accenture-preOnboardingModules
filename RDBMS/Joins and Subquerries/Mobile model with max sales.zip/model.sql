-- select Model_Name, count(s.ime_no) as "MAX_SALES"
-- from mobile_master m 
-- join sales_info s
-- on m.ime_no=s.ime_no
-- group by Model_Name
-- having count(s.ime_no)=
-- (select max(mycount)
-- from
-- (select ime_no,count(ime_no) as mycount
-- from sales_info
-- group by ime_no))
-- order by Model_Name desc;


select to_char(sales_date,'MONTH') as m, sum(price) as amount
from sales_info
where to_char(sales_date,'Year')>to_char(add_months(year,-1,getdate()),'Year')
group by to_char(sales_date,'MONTH')
order by sum(price) desc;
