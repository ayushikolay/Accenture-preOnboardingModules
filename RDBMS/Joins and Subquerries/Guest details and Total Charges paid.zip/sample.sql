select g.guestid, g.name, sum(b.totalcharge) as TOTALPAID
from guest g 
inner join 
booking b 
on g.guestid=b.guestid
group by g.guestid,g.name
having sum(b.totalcharge)>= 50000
order by g.guestid;