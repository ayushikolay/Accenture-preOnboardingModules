select d.department_name,count(s.student_id) as student_count
from department d 
inner join
student s 
on d.department_id =s.department_id
group by d.department_name
order by d.department_name;