select  distinct bus_no, bus_name
from buses
where bus_no in 
(select s1.bus_no from schedule s1
inner join schedule s2
on s1.source=s2.destination
and s1.destination=s2.source)
order by bus_no;
