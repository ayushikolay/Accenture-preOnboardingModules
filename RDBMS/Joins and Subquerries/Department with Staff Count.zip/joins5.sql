select d.department_name, nvl(count(s.staff_id),0) as staff_count
from department d 
left join 
staff s 
using(department_id)
group by d.department_name
order by d.department_name;
