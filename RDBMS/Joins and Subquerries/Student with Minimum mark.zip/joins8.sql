select s.subject_name, min(m.value) as min_mark
from subject s 
inner join 
mark m 
using(subject_id)
group by s.subject_name
order by s.subject_name desc;