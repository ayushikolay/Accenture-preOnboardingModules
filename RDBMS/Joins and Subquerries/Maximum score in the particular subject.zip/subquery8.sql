select student_name
from student 
where student_id in (select student_id from mark where value=
(select max(value) from mark 
join subject
on mark.subject_id=subject.subject_id
where lower(subject.subject_name)='software engineering'))
order by student_name;