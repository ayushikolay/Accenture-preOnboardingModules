select r.resortName, c.rate
from resort r 
inner join cabincost c 
on r.resortID=c.resortID
where c.rate=(select max(rate) from cabincost)
order by resortName;