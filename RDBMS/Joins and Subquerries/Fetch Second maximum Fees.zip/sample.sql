select courseid, coursename
from course 
where fees = 
(select max(fees) from course 
where fees not in 
(select max(fees) from course))
order by courseid;