select townname
from town 
where summertemp > (select summertemp from town where lower(townname)='jaipur')
order by townname;