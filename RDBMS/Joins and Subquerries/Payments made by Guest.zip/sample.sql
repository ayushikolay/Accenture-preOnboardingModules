select  g.name, r.resortName, b.fromdate, b.todate, b.adultCount, b.childCount, b.totalcharge
from guest g 
join booking b 
on g.guestID=b.guestID
join resort r
on b.resortID=r.resortID
order by g.guestID;




