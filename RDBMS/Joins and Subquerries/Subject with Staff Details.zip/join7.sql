select s.subject_name, s.subject_code,st.staff_name
from subject s 
join staff st 
on s.staff_id=st.staff_id
order by s.subject_code;