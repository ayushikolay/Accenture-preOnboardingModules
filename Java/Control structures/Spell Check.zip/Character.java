import java.util.*;
class Character{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String str="";
        
        System.out.print("Enter the first letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the second letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the third letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the fourth letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the fifth letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the sixth letter:");
        str+=sc.next();
        
        System.out.print("\nEnter the seventh letter:");
        str+=sc.next();
        
        if(str.equals("RAINBOW"))
        {
            System.out.print("\nRAINBOW");
        }
        else
        {
            System.out.print("\nThe spelling is wrong");
        }
        
    }
    
    
}