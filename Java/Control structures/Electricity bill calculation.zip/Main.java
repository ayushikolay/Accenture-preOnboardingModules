
import java.util.Scanner;

public class Main{
    
    public static void main(String[] args){
        
       Scanner sc=new Scanner(System.in);
       
        System.out.println("Enter the units consumed");
        double usage=sc.nextDouble();
        
        if(usage > 20 && usage < 100)
        {
            usage=3.50*usage;
            
        }
        else if(usage >= 100)
        {
            usage=usage*5;
        }
        else
        {
            System.out.println("No Charge");
            return;
        }
        
        System.out.println("You have to pay Rs."+usage);
        
    }
    
}