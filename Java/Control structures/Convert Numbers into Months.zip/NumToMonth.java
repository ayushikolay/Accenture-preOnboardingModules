import java.util.*;
class NumToMonth{
    
    public static void main(String[] args)
    {
        
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        
        if(n<1 || n>12)
        {
            System.out.print("\nNo month for the number "+n);
            return;
        }
        
        switch(n)
        {
            case 1:System.out.print("\nJanuary");
            break;
            
            case 2:System.out.print("\nFebruary");
                   break;
                   
            case 3:System.out.print("\nMarch");
            break;
            
            case 4:System.out.print("\nApril");
            break;
            
            
            case 5:System.out.print("\nMay");
            break;
            
            
            case 6:System.out.print("\nJune");
            break;
            
            case 7:System.out.print("\nJuly");
            break;
            
            case 8:System.out.print("\nAugust");
            break;
            
            case 9:System.out.print("\nSeptember");
            break;
            
            case 10:System.out.print("\nOctober");
            break;
            
            case 11:System.out.print("\nNovember");
            break;
            
            default:System.out.print("\nDecember");
            break;
            
            
            
            
        }
        
        
    }
    
}


