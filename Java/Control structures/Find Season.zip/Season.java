import java.util.*;

class Season{
    
    public static void main(String[] args)
    {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the month:");
        int n=sc.nextInt();
        
        if(n<1 || n > 12)
        {
            System.out.print("\nInvalid month");
            return;
        }
        
        if(n>=3 && n<=5)
        {
            System.out.print("\nSeason:Spring");
        }
        else if(n>= 6 && n<=8)
        {
            System.out.println("\nSeason:Summer");
        }
        else if(n>=9 && n<=11)
        {
            System.out.println("\nSeason:Autumn");
        }
        else
        {
            System.out.println("\nSeason:Winter");
        }
        
        
    }
    
}




