import java.util.*;
class IncrementCalculation
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the salary");
        long sal=sc.nextLong();
        
        System.out.println("Enter the Performance appraisal rating");
        float n=sc.nextFloat();
        
        if(sal <=0 || n<1 || n>5)
        {
            System.out.println("Invalid Input");
            return;
        }
        
        double salary=0;
        if(n>=1 && n<=3)
        {
            salary=(sal*11)/10;
            
        }
        else if(n>=3.1 && n<=4)
        {
            salary=(sal*5)/4;
        }
        else
        {
            salary=(sal*13)/10;
        }
        
        
        System.out.println((int)salary);
        
    }
}