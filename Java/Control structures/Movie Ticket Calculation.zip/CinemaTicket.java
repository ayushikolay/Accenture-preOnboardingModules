import java.util.*;
class CinemaTicket
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the no of ticket:");
        int ticket=sc.nextInt();
        sc.nextLine();
        
        if(ticket < 5 || ticket > 40)
        {
            System.out.print("\nMinimum of 5 and Maximum of 40 Tickets");
            return;
        }
        
        System.out.print("\nDo you want refreshment:");
        char ref=sc.next().charAt(0);
        
        System.out.print("\nDo you have coupon code:");
        char code=sc.next().charAt(0);
        
        System.out.print("\nEnter the circle:");
        char cir=sc.next().charAt(0);
        
        
        if(!(cir == 'k' || cir == 'q'))
        {
            System.out.print("\nInvalid Input");
            return;
        }
        
        
        double total=0;
        
        if(ticket > 20)
        {
            
            if(cir == 'k')
            {
                total=(75*ticket*0.9);
                if(code=='y')
                {
                    total=total*0.98;
                }
                if(ref=='y')
                {
                    total=total+(ticket*50);
                }
            }
            else
            {
                total=(150*ticket*0.9);
                if(code == 'y')
                {
                    total=total*0.98;
                    
                }
                if(ref == 'y')
                {
                    total=total+(ticket*50);
                }
            }
            
        }
        else
        {
            if(cir =='k')
            {
                total=75*ticket;
                
                if(code == 'y')
                {
                    total=total*0.98;
                }
                if(ref =='y')
                {
                    total=total+(ticket*50);
                }
            }
            else
            {
                total=150*ticket;
                if(code == 'y')
                {
                    total=total*0.98;
                }
                if(ref == 'y')
                {
                    total=total+(ticket*50);
                }
            }
        }
        
        System.out.print("Ticket cost:");
        System.out.printf("%.02f",total);
        
        
    }
    
}

