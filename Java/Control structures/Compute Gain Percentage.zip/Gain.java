import java.util.*;

class Gain 
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Price of old scooter:");
        int cp=sc.nextInt();
        
        System.out.println("The amount spent for repair:");
        int amt=sc.nextInt();
        
        System.out.println("Sold Price:");
        int sp=sc.nextInt();
        
        
        if(cp <= 0 || sp <= 0 || amt < 0)
        {
            
            System.out.println("Incorrect Inputs");
            return;
            
        }
        
        
        if(sp <= (cp+amt))
        {
            System.out.println("Unable to calculate Gain Percentage");
            return;
        }
        
        int gain=sp-(cp+amt);
        
        double gp=(double)(gain*100)/(cp+amt);
        
        System.out.print("Gain percentage is ");
        System.out.printf("%.02f",gp);
        
        
    }
}
