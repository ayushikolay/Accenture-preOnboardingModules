import java.util.*;
class Placement
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the no of students placed in CSE:");
        int cse=sc.nextInt();
        
        System.out.print("\nEnter the no of students placed in ECE:");
        
        int ece=sc.nextInt();
        
        System.out.print("\nEnter the no of students placed in MECH:");
        int mech=sc.nextInt();
        
        if(cse<0 || ece<0 || mech<0)
        {
            System.out.print("\nInput is invalid");
            return;
        }
        
        if(cse == ece && ece == mech)
        {
            System.out.print("\nNone of the department has got the highest placement");
            return;
        }
        
        System.out.println("\nHighest placement");
        if(cse >= ece)
        {
            if(cse == ece)
            {
                System.out.print("\nCSE");
                System.out.print("\nECE");
            }
            else if(cse == mech)
            {
                System.out.print("\nCSE");
                System.out.print("\nMECH");
            }
            else if(cse > mech)
            {
                System.out.print("\nCSE");
            }
            else
            {
                System.out.print("\nMECH");
            }
        }
        else
        {
            if(mech == ece)
            {
                System.out.print("\nECE");
                System.out.print("\nMECH");
            }
            else if(ece > mech)
            {
                System.out.print("\nECE");
            }
            else
            {
                System.out.print("\nMECH");
            }
        }
        
        
    }
    
}


