import java.util.*;
class LeapYear
{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Year");
        int year=sc.nextInt();
        
        int temp=year;
        int c=0;
        boolean flag=false;
        
        while(temp>0)
        {
            temp/=10;
            c++;
        }
        
        if(c!=4)
        {
            System.out.println("Invalid Year");
            return;
        }
        
        
        if(year%4==0)
        {
            if(year%100 == 0)
            {
                if(year%400 == 0)
                {
                    flag=true;
                }
            }
            else
            {
                flag=true;
            }
        }
        
        if(flag)
        {
            System.out.println("Leap Year");
        }
        else
        {
            System.out.println("Not a Leap Year");
        }
        
        
    }
    
    
}