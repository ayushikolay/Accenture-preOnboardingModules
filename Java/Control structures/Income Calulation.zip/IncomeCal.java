import java.util.*;

class IncomeCal{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter no of hours worked in a day:");
        int h=sc.nextInt();
        
        if(h < 0 || h>24)
        {
            System.out.println("\nUnable to calculate the earnings");
            return;
        }
        
        long total=h*100*365;
        
        System.out.println("\nTotal income in a year:"+total);
        
  
    }
    
}
