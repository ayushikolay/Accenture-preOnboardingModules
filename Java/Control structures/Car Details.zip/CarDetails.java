import java.util.*;
class CarDetails{
    
    public static void main(String args[])
    {
    Scanner sc=new Scanner(System.in);
    
    System.out.print("Enter the car name:");
    String car=sc.nextLine();
    
    System.out.print("\nEnter the car no:");
    long carno=sc.nextLong();
    
    System.out.print("\nEnter the price:");
    double price=sc.nextDouble();
    
    
    System.out.println("\nCarname:"+car);
    System.out.println("Carno:"+carno);
    System.out.println("Price:"+String.format("%.02f",price)+" rs only");
    
    }
}


