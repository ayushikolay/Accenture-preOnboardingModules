import java.util.*;
class CelsiusConversion{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        double C=sc.nextInt();
        
        double fah=((9*C)/5)+32;
        
        System.out.printf("%.01f",fah);
        
    }
}



