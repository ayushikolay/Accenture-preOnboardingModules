import java.util.*;
class Customer{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter your name:");
        String name=sc.nextLine();
        
        System.out.print("\nEnter age:");
        int age=sc.nextInt();
        sc.nextLine();
        
        System.out.print("\nEnter gender:");
        String gender=sc.nextLine();
        
        
        System.out.print("\nHailing from:");
        String country=sc.nextLine();
        
        
        System.out.println("\nWelcome, "+name);
        System.out.println("Age:"+age);
        System.out.println("Gender:"+gender);
        System.out.print("City:"+country);
        
        
    }
    
}