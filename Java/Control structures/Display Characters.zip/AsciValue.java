import java.util.*;
class AsciValue{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the digits:");
        
        int d1=sc.nextInt();
        int d2=sc.nextInt();
        int d3=sc.nextInt();
        int d4=sc.nextInt();
        
        
        char c1=(char)d1;
        char c2=(char)d2;
        char c3=(char)d3;
        char c4=(char)d4;
        
        System.out.println(d1+"-"+c1);
        System.out.println(d2+"-"+c2);
        System.out.println(d3+"-"+c3);
        System.out.println(d4+"-"+c4);
        
    }
    
}