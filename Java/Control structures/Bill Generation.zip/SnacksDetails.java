import java.util.*;
class SnacksDetails{
    
    public static void main(String[] args)
    {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the no of pizzas bought:");
        int piz=sc.nextInt();
        
        System.out.print("\nEnter the no of puffs bought:");
        int puff=sc.nextInt();
        
        System.out.print("\nEnter the no of cool drinks bought:");
        int cd=sc.nextInt();
        
        
        long total=(100*piz)+(20*puff)+(10*cd);
        
        System.out.println("\nBill Details");
        System.out.println("No of pizzas:"+piz);
        System.out.println("No of puffs:"+puff);
        System.out.println("No of cooldrinks:"+cd);
        System.out.println("Total price="+total);
        System.out.println("ENJOY THE SHOW!!!");
        
        
        
    }
    
    
}