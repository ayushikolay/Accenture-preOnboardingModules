import java.util.*;

class RegistrationDetails{
    
    public static void main(String[] args)
    {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter your name:");
        String name=sc.nextLine();
        
        
        System.out.print("\nEnter your age:");
        int age=sc.nextInt();
        
        
        System.out.print("\nEnter your phoneno:");
        long phn=sc.nextLong();
        sc.nextLine();
        
        System.out.print("\nEnter your qualification:");
        String qualification=sc.nextLine();
        
        System.out.print("\nEnter your email id[Please provide valid id, after registering your registration id will be mailed]:");
        String mail=sc.nextLine();
        
        System.out.print("\nEnter your noofexperience[if any]:");
        float exp=sc.nextFloat();
        
        
        
        System.out.print("\nDear "+name+", Thanks for registering in our portal, registration id will be mailed to "+mail+" within 2 working days");
        
        
    }
    
    
}









