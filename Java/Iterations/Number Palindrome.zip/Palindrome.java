import java.util.*;
class Palindrome
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        
        if(n<0)
        {
            System.out.println("Invalid Input");
            return;
        }
        
        int temp=0;
        int t=n;
        while(t>0)
        {
            temp=(temp*10)+(t%10);
            t/=10;
        }
        
        if(temp == n)
        {
            System.out.println("Palindrome");
        }
        else
        {
            System.out.println("Not a Palindrome");
        }
        
        
    }
    
}