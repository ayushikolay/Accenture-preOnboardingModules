import java.util.Scanner;

public class Main {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		// Fill the code
		
		System.out.println("Enter the number");
		int n=sc.nextInt();
		
		int temp=0;
		while(n>0)
		{
		    int x=n%10;
		    temp=(temp*10)+x;
		    n/=10;
		}
		
		System.out.println(temp);
		
	}

}
