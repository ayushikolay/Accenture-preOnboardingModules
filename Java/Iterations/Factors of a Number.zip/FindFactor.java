import java.util.*;
class FindFactor
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        int n=sc.nextInt();
        
        if(n==0)
        {
            System.out.println("No Factors");
            return;
        }
        
        if(n<0)
        {
            n=-(n);
        }
        
        
        int temp=1;
        int i=1;
        while(temp<n)
        {
            if(n%temp ==0)
            System.out.print(temp+", ");
            
            temp++;
            
        }
        
        System.out.print(temp);
        
    }
    
}