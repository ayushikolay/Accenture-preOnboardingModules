import java.util.Scanner;

public class Main {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		// Fill the code
		
		
		System.out.println("Enter starting range");
		int s=sc.nextInt();
		
		System.out.println("Enter ending range");
		int e=sc.nextInt();
		
		int c=0;
		
		for(int i=s;i<=e;i++)
		{
		    boolean flag=false;
		    for(int j=2;j<=i/2;j++)
		    {
		        if(i%j==0)
		        {
		            flag=true;
		            break;
		        }
		    }
		    
		    if(!flag)
		    {
		        c++;
		    }
		    
		}
		
		System.out.println(c);
		
	}

}
