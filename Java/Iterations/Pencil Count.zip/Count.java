import java.util.*;
class Count 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.print("Enter the standard: ");
        int n=sc.nextInt();
        
        int pencil=0;
        
        if(n<1 || n> 12)
        {
            System.out.println("\nInvalid Standard");
            return;
        }
        
        for(int i=1;i<=n;i++)
        {
            pencil+=i*i;
            
        }
        
        System.out.println("\nNila gets "+pencil+" pencils");
        
    }
    
}