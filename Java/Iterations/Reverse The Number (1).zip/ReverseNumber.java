import java.util.*;
class ReverseNumber
{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Number:");
        int n=sc.nextInt();
        
        if(n < 0)
        {
            System.out.println("Number should be positive");
            return;
        }
        
        if(n == 0)
        {
            System.out.println("Output is:0");
            return;
        }
        
        int temp=0;
        while(n >0)
        {
            temp=(temp*10)+(n%10);
            n/=10;
            
        }
        
        System.out.println("Output is:"+temp);
        
        
    }
    
}