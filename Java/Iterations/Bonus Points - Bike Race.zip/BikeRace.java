import java.util.*;
class BikeRace
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the distance travelled");
        int distance=sc.nextInt();
        
        if(distance < 0)
        {
            System.out.println("Invalid input");
            return;
        }
        
        if(distance == 0)
        {
            System.out.println("Your bonus points is "+0);
            return;
        }
        
        int evenprod=1;
        int oddprod=1;
        
        int temp=distance;
        
        int l=0;
        while(temp>0)
        {
            l++;
            temp/=10;
        }
        
        temp=distance;
        
        for(int i=1;i<=l;i++)
        {
            if(i%2 == 0)
            {
                evenprod*=(temp%10);
            }
            else
            {
                oddprod*=(temp%10);
            }
            
            temp/=10;
            
        }
        
        if(evenprod == oddprod)
        {
            System.out.println("Your bonus points is "+(2*evenprod));
            return;
        }
        
        System.out.println("Your bonus points is "+Math.max(oddprod,evenprod));
        
        
    }
    
}