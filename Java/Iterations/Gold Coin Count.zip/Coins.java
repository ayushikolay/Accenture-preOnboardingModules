import java.util.*;
class Coins
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
       System.out.print("Enter the age: ");
       int n=sc.nextInt();
       
       if(n<=0)
       {
           System.out.print("\nInvalid Age");
           return;
       }
       
       long coins=(long)Math.pow(n,3);
       
       System.out.print("\nMeenu gets "+coins+" coins");
       
        
    }
    
}