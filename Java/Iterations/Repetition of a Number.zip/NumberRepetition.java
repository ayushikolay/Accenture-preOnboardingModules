import java.util.*;
class NumberRepetition
{
    public static void main(String[] args)
    {
    Scanner sc=new Scanner(System.in);
    System.out.print("Enter the number ");
    int n=sc.nextInt();
    
    System.out.print("\nEnter the key digit ");
    int key=sc.nextInt();
    
    int temp=n;
    int count=0;
    
    while(temp>0)
    {
        if((temp%10) == key)
        {
            count++;
            
        }
        temp/=10;
        
    }
    
    
    System.out.print("\n"+key+" appears "+count+" times in "+n);
    
    }
    
}