import java.util.Scanner;

public class Main {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		// Fill the code
		
		System.out.println("Enter the starting range");
		int s=sc.nextInt();
		
		System.out.println("Enter the ending range");
		int e=sc.nextInt();
		
		
		for(int i=s;i<=e;i++)
		{
		    
		    int temp=0;
		    int t=i;
		    
		    while(t>0)
		    {
		        
		        int x=t%10;
		        temp=(temp*10)+x;
		        t/=10;
		        
		    }
		    
		    if(temp == i)
		    {
		        System.out.print(i+" ");
		    }
		    
		    
		}
		
		
	}

}
