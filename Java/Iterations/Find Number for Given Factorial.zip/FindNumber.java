import java.util.*;
class FindNumber
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        
        if(n<=0)
        {
            System.out.println("Invalid Input");
            return;
        }
        
        int i=2;
        int temp=1;
        
        while(temp<n)
        {
            temp*=i;
            i++;
            
        }
        
        
        if(temp == n)
        {
            System.out.println(i-1);
            return;
        }
        
        if(temp<n || temp>n)
        {
            System.out.println("Sorry. The given number is not a perfect factorial");
        }
        
        
    }
    
}