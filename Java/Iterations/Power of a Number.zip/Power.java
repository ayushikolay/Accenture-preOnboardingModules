import java.util.*;
class Power
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the number");
        int num=sc.nextInt();
        
        System.out.println("Enter the digit");
        int dig=sc.nextInt();
        
        if(num < 0 || dig < 0)
        {
            System.out.println("Invalid Input");
            return;
        }
        
        long x=(long)Math.pow(num,dig);
        System.out.println(x);
        
    }
    
}