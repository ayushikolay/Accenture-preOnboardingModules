import java.util.Scanner;

public class Main {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		// Fill the code
		
		
		System.out.println("Enter the String");
		String str=sc.nextLine();
		
		System.out.println("Enter the number");
		int n=sc.nextInt();
		
		if(n<1)
		{
		    System.out.println(n+" is not a valid input");
		    return;
		}
		
		for(int i=1;i<=n;i++)
		{
		    System.out.println(str);
		}
		
		
	}

}
