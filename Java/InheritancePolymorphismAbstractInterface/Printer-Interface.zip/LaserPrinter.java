//create a class ,override the print() method and return the String as expected in the problem statement

public class LaserPrinter implements Printer
{
    
    public String print()
    {
        return ("Laser Printer Printing");
        
    }
  
    
}

