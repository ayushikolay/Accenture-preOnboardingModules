 //Create a interface Printer with an abstract method print
 //print method signature: public String print()
interface Printer
{
    abstract String print();
    
}
 
 
 