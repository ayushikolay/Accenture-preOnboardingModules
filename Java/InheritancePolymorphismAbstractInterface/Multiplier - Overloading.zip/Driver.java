public class Driver{
    
    public static void main(String[] args){
        
        //create the object of Multiplier and invoke the overloaded methods 
        Multiplier m=new Multiplier();
        System.out.println(m.multiply(4,5));
        System.out.println(m.multiply(4,5,6));
        System.out.println(m.multiply(4.5,6.5));
        
    }
    
}