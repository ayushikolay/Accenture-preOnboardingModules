import java.util.*;

public class Course
{
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter no of course:");
        int n=sc.nextInt();
       sc.nextLine();
        
        if(n<=0 || n>20)
        {
            System.out.println("Invalid Range");
            return;
        }
        
        
        System.out.println("Enter course names:");
        
        String names[]=new String[n];
        for(int i=0;i<n;i++)
        {
            names[i]=sc.nextLine();
        }
        
        System.out.println("Enter the course to be searched:");
        String c=sc.nextLine();
        
        for(int i=0;i<n;i++)
        {
            if(names[i].equals(c))
            {
                System.out.println(c+" course is available");
                return;
            }
        }
        
        System.out.println(c+" course is not available");
        
    }
    
    
}