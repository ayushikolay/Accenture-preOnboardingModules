
import java.util.Scanner;
import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the array size");
        int n=sc.nextInt();
        
        int arr[]=new int[n];
        System.out.println("Enter the values");
        
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        
        for(int j=0;j<n;j++)
        {
            for(int k=j;k<n;k++)
            {   int t=0;
                if(arr[j]>arr[k])
                {
                    t=arr[j];
                    arr[j]=arr[k];
                    arr[k]=t;
                }
            }
        }
        
        
       // Arrays.sort(arr);
        for(int i=0;i<n;i++)
        {
            System.out.println(arr[i]);
        }
        
        
    }
}