import java.util.*;
public class Count 
{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the no of subjects:");
        int n=sc.nextInt();
        
        if(n<=0 || n>20)
        {
            System.out.println("Invalid input range");
            return;
        }
        
        int arr[]=new int[n];
        
        int p=0,f=0;
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
            if(arr[i]<50)
            {
                f++;
            }
            else 
            {
                p++;
            }
        }
        
        if(f==n)
        {
            System.out.println("Ram failed in all subjects");
            return;
        }
        
        if(p == n)
        {
            System.out.println("Ram passed in all subjects");
            return;
        }
        
        
        System.out.println("Ram passed in "+p+" subjects and failed in "+f+" subjects");
        
        
        
    }
    
}