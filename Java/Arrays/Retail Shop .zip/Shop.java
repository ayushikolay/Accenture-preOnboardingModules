import java.util.*;
public class  Shop 
{
  
    private String shopName;
    private String shopAddress;
    private String[] products;
        
    public Shop(String shopName,String shopAddress,String[] products)
    {
        this.shopName=shopName;
        this.shopAddress=shopAddress;
        this.products=products;
    }
    
    
    public boolean checkProductAvailability(String productname)
    {
        for (int i=0;i<products.length ;i++ )
        {
            if(productname.equalsIgnoreCase(products[i]))
            {
                return true;
            }
            
        }
        return false;
        
    }
    
    public String getShopAddress()
    {
        return this.shopAddress;
    }
    
    public String getShopName()
    {
        return this.shopName;
    }
    
    public String[] getProducts()
    {
        return this.products;
    }
    
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        
        
        System.out.println("Enter the shopname:");
        String shopname=sc.nextLine();
        
        System.out.println("Enter the address:");
        String address=sc.nextLine();
        
        System.out.println("Enter number of products:");
        int n=sc.nextInt();
        sc.nextLine();
        
        
        String products[]=new String[n];
        
        for(int i=0;i<n;i++)
        {
            products[i]=sc.nextLine();
        }
        
        Shop sh=new Shop(shopname,address,products);
        
        System.out.println("Enter the product to be searched");
        String pro=sc.nextLine();
        
        boolean isAvailable=sh.checkProductAvailability(pro);
        
        if(isAvailable)
        {
            System.out.println("Product is available at "+sh.getShopName()+", "+sh.getShopAddress());
            return;
        }
        
        
        System.out.println("Product is not available at "+sh.getShopName()+", "+sh.getShopAddress());
        
        
    }
    
    
}