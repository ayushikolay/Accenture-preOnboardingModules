import java.util.*;

public class CompatibleArrays
{
    
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size for First array:");
        
        int n=sc.nextInt();
        
        if(n<=0)
        {
            System.out.println("Invalid array size");
            return;
        }
        
        
        int arr[]=new int[n];
        System.out.println("Enter the elements for First array:");
        
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        
        System.out.println("Enter the size for Second array:");
        int n2=sc.nextInt();
        
        if(n2<=0)
        {
            System.out.println("Invalid array size");
            return;
        }
        
        int arr2[]=new int[n2];
        System.out.println("Enter the elements for Second array:");
        for(int i=0;i<n2;i++)
        {
            arr2[i]=sc.nextInt();
        }
        
        
        if(n!=n2)
        {
            System.out.println("Arrays are Not Compatible");
            return;
        }
        
        
        for(int i=0;i<n;i++)
        {
            if(arr[i] < arr2[i])
            {
                System.out.println("Arrays are Not Compatible");
                return;
            }
        }
        
        System.out.println("Arrays are Compatible");
        
        
    }
    
    
}
