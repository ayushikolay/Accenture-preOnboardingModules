import java.util.*;
public class ArrayAccumulator
{
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of first array:");
        int n1=sc.nextInt();
        
        if(n1<=0)
        {
            System.out.println("Invalid array size");
            return;
        }
         System.out.println("Enter elements for first array:");
        
        
        int arr1[]=new int[n1];
        
        for(int i=0;i<n1;i++)
        {
            arr1[i]=sc.nextInt();
        }
        
        
        System.out.println("Enter the size of second array:");
        
        int n2=sc.nextInt();
        
        if(n2<=0)
        {
            System.out.println("Invalid array size");
            return;
        }
        
        System.out.println("enter elements for second array:");
        int arr2[]=new int[n2];
        for(int i=0;i<n2;i++)
        {
            arr2[i]=sc.nextInt();
        }
        
        int arr[];
        if(n1>n2)
        {
            arr=new int[n1];
                
        }
        else if(n2>n1)
        {
            arr=new int[n2];
        }
        else 
        {
            arr=new int[n1];
        }
        
        int i=0,j=0,k=0;
       while(n1-->0 && n2-->0)
        {
            arr[k]=arr1[i]+arr2[j];
            k++;
            i++;
            j++;
            
        }
        
        while(n1-->0)
        {
            arr[k]=arr1[i];
            i++;
            k++;
        }
        
        while(n2-->0)
        {
            arr[k]=arr2[j];
            j++;
            k++;
        }
        
        for(int a=0;a<arr.length;a++)
        {
            System.out.println(arr[a]);
        }
        
        
    }
    
}