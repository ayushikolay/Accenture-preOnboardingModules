import java.util.*;

public class StudentMain
{
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        Student s=new Student();
        System.out.println("Enter the id:");
        
        s.setId(sc.nextInt());
        sc.nextLine();
        
        System.out.println("Enter the name:");
        s.setName(sc.nextLine());
        
        System.out.println("Enter the no of subjects:");
        int n=sc.nextInt();
      
        
        int arr[]=new int[n];
        
        for(int i=0;i<n;i++)
        {
            
          System.out.println("Enter mark for subject "+(i+1)+":");
          arr[i]=sc.nextInt();
        
        }
        
        s.setMarks(arr);
        
        System.out.print("Id:");
        System.out.print(s.getId());
        
        System.out.print("\nName:");
        System.out.print(s.getName());
        
        s.calculateAvg();
        System.out.print("\nAverage:");
        System.out.print(s.getAverage());
        
        s.findGrade();
        System.out.print("\nGrade:");
        System.out.print(s.getGrade());
        
        
        
    }
    
    
    
}