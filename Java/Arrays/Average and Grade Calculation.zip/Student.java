public class Student
{
    private int id;
    private String name;
    private int[] marks;
    private float average;
    private char grade;
    
    
    public void setId(int id)
    {
        this.id=id;
    }
    
    public int getId()
    {
        return this.id;
    }
    
    public void setName(String name)
    {
        this.name=name;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public void setMarks(int[] marks)
    {
        this.marks=marks;
    }
    
    public int[] getMarks()
    {
        return this.marks;
    }
    
    public void calculateAvg()
    {
        
        float sum=0;
        int n=this.marks.length;
        for(int i=0;i<n;i++)
        {
            
            sum+=this.marks[i];
        }
        
        average=(float)sum/n;
        
        setAverage(average);
        
        
    }
    
    public void setAverage(float average)
    {
        this.average=average;
    }
    
    
    public float getAverage()
    {
        return this.average;
    }
    
    
    public void setGrade(char grade)
    {
        this.grade=grade;
        
    }    
    
    public char getGrade()
    {
        return this.grade;
    }
    
    
    public void findGrade()
    {
        char grade;
        int flag=0;
        
        for(int i=0;i<this.marks.length;i++)
        {
            if(this.marks[i]<50)
            {
                flag++;
            }
        }
        
        if(flag>0)
        {
            setGrade('F');
            return;
        }
        
        
        float average=getAverage();
        if(average >=80 && average<=100)
        {
            grade='O';
        }
        
        else if(average>=50 && average<=79)
        {
            grade='A';
            
        }
        else 
        {
            grade='F';
        }
        
        setGrade(grade);
        
    }
    
    
    
}