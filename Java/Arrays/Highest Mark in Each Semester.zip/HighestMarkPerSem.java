import java.util.*;
public class HighestMarkPerSem
{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
    

System.out.println("Enter no of semester:");
int n=sc.nextInt();
int sem[][]=new int[n][];

for(int i=0;i<n;i++)
{
    System.out.println("Enter no of subjects in "+(i+1)+" semester:");
    int j=sc.nextInt();
    sem[i]=new int[j];
}

for(int i=0;i<n;i++)
{
    System.out.println("Marks obtained in semester "+(i+1)+":");
    for(int j=0;j<sem[i].length;j++)
    {
        int mark=sc.nextInt();
        if(mark < 0 || mark > 100)
        {
            System.out.println("You have entered invalid mark.");
            return;
        }
        sem[i][j]=mark;
    }
}

//int max=Integer.MIN_VALUE;
int arr[]=new int[n];

for(int i=0;i<n;i++)
{
    int max=Integer.MIN_VALUE;
    for(int j=0;j<sem[i].length;j++)
    {
        if(sem[i][j]>max)
        {
            max=sem[i][j];
        }
    }
    
    arr[i]=max;
   // System.out.println("Maximum marks in "+(i+1)" semester:"+max);
}


   for(int i=0;i<n;i++)
   {
       System.out.println("Maximum mark in "+(i+1)+" semester:"+arr[i]);
   }

}

}