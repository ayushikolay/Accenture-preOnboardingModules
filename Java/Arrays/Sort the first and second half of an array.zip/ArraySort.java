import java.util.*;

public class ArraySort 
{
    
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the size of an array:");
        int n=sc.nextInt();
        
        if(n<=0)
        {
            System.out.println("Array size should be greater than 0");
            return;
        }
        
        System.out.println("Enter the elements:");
        int arr[]=new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        
        int arr1[]=Arrays.copyOfRange(arr,0,(n+1)/2);
        int arr2[]=Arrays.copyOfRange(arr,(n+1)/2,n);
        
        Arrays.sort(arr1);
        Arrays.sort(arr2);
        
        int k=0;
        for(int i=0;i<arr1.length;i++)
        {
            arr[k]=arr1[i];
            k++;
            
        }
        
        for(int i=arr2.length-1;i>=0;i--)
        {
            arr[k]=arr2[i];
            k++;
        }
        
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
        
        
    }
    
    
}