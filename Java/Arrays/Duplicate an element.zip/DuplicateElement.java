import java.util.*;
public class DuplicateElement
{
    
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the size of an array:");
        int n=sc.nextInt();
        
        if(n<=0)
        {
            System.out.println("Invalid array size");
            return;
        }
        
        
        System.out.println("Enter the array elements:");
        int arr[]=new int[n];
        
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        
        System.out.println("Enter the position of the element to be replicated:");
        int pos=sc.nextInt();
        
        if(pos>=n)
        {
            System.out.println("Position is greater than the size of an array");
            return;
        }
        
        int array[]=new int[n+1];
        int i=0;
        for(i=0;i<n;i++)
        {
            array[i]=arr[i];
        }
        
        array[i]=arr[pos];
        
        
        for(i=0;i<=n;i++)
        {
            System.out.println(array[i]);
        }
        
        
        
    }
}


