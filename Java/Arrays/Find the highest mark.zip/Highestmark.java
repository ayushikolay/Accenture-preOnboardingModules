import java.util.*;
public class Highestmark
{
    
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[6];
        
        int max=Integer.MIN_VALUE;
        for(int i=0;i<6;i++)
        {
            int mark=sc.nextInt();
            if(mark<0)
            {
                System.out.println("Invalid mark");
                return;
            }
            
            arr[i]=mark;
            if(arr[i]>max)
            {
                max=arr[i];
            }
        }
        
        System.out.println("Highest mark is "+max);
        
        
    }
    
    
    
    
    
    
}