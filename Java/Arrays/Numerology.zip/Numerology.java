import java.util.*;
public class Numerology
{
    
   static char[][] numerology={{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},
                          {1,2,3,4,5,8,3,5,1,1,2,3,4,5,7,8,1,2,3,4,6,6,6,5,1,7}};
                          
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        
       System.out.println("Enter your name:");
       String name=sc.nextLine();
       
       int length=name.length();
       
       int val=0;
       for(int i=0;i<length;i++)
       {
           char ch=name.charAt(i);
           
           int temp=numerical_value(ch);
           
           
           if(temp == 0)
           {
               System.out.println("Invalid name");
               return;
           }
           else 
           {
              val+=(int)temp;
              
           }
       }
               System.out.println("Your numerology no is:"+val);
         
       
       
    }
       
    //   char numerology[][]={{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},
    //                         {1,2,3,4,5,8,3,5,1,1,2,3,4,5,7,8,1,2,3,4,6,6,6,5,1,7}};
       
      
        
     public static char numerical_value(char ch)
     {
         for(int i=0;i<26;i++)
         {
             if(numerology[0][i]==ch)
             {
                 return numerology[1][i];
             }
         }
         
         return 0;
     }
    
    
}