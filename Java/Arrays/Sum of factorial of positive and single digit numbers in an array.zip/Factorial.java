import java.util.*;
public class Factorial
{
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of an array");
        int size=sc.nextInt();
        
        int arr[]=new int[size];
        System.out.println("Enter the elements:");
        for(int i=0;i<size;i++)
        {
            arr[i]=sc.nextInt();
            
        }
        
        int sum=0;
        for(int i=0;i<size;i++)
        {
            int length=String.valueOf(arr[i]).length();
            if(length==1 && arr[i]>0)
            {
                sum+=fact(arr[i]);
            }
            
        }
        
        if(sum>0)
        {
            System.out.println(sum);
            return;
        }
        
        
        System.out.println("No positive and single digit numbers found in an array");
        
    }
    
    public static int fact(int n)
    {
        int f=1;
        while(n>1)
        {
            f*=n;
            n--;
        }
        return f;
    }
    
}

