import java.util.*;
public class Test 
{
    public static float calculateAverage(int[] age)
    {
        int sum=0;
        int n=age.length;
        float avg=0;
        for(int i=0;i<n;i++)
        {
            sum+=age[i];
        }
        
        avg=(float)sum/n;
        return avg;
        
    }
    
    
    public static void main (String[] args) {
        
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter total no.of employees:");
        int n=sc.nextInt();
        
        
        if(n<=1)
        {
            System.out.println("Please enter a valid employee count");
            return;
        }
        
        
        System.out.println("Enter the age for "+n+" employees:");
        int arr[]=new int[n];
        
        for(int i=0;i<n;i++)
        {
            int ag=sc.nextInt();
            if(ag<28 || ag>40)
            {
                System.out.println("Invalid age encountered");
                return;
            }
            
            
            arr[i]=ag;
            
        }
        
        float avg=(float)calculateAverage(arr);
        System.out.println("The average age is "+String.format("%.2f",avg));
        
        
        
    }
    
    
    
} 