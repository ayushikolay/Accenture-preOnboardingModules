
public class PlayerUtility {

	public Player findPlayerDetailsById(Player[] arr, int playerIdToSearch){
	
       for(int i=0;i<arr.length;i++)
       {
           if(arr[i].getPlayerId()==playerIdToSearch)
           {
            //   System.out.println("Name:"+arr[i].getPlayerName());
            //   System.out.println("Phone number:"+arr[i].getPhoneNumber());
              return arr[i];
               
           }
           
           //return null;
           //System.out.println("No player found");
       }
	
		return null;
	}
	
	
}
