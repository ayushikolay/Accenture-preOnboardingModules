package com.sbcc.utility;
import java.util.regex.*;
import com.sbcc.model.Player;

public class SBCCUtility {
	
	// Include the logic of parsePlayerDetails method as specified in the requirement document - 2
    	public Player parsePlayerDetails(String playerDetails)
    	{
    	    Player p=new Player();
    	    String[] s=playerDetails.split(":");
    	    
    	    String playerId=s[0];
    	    
    	    if(validatePlayerId(playerId)==false)
    	    {
    	        return null;
    	    }
    	    
    	    p.setPlayerId(playerId);
    	    
    	    String playerName=s[1];
    	    p.setPlayerName(playerName);
    	    
    	    int matchesPlayed=Integer.parseInt(s[2]);
    	    p.setMatchesPlayed(matchesPlayed);
    	    
    	    String securedRuns[]=new String[matchesPlayed];
    	    
    	    for(int i=0;i<matchesPlayed;i++)
    	    {
    	        securedRuns[i]=s[3+i];
    	    }
    	    
    	    int total=p.calculateTotalRuns(securedRuns);
    	    
    	    p.setRunScored(total);
    	    
    	    p.setPlayingZone(s[3+matchesPlayed]);
    	    
    	    return p;
    	    
    	    
    	}
    	
    	
    	public boolean validatePlayerId(String playerId)
    	{
    	    Pattern p=Pattern.compile("[A-Z]{4}[0-9]{4}[A-Z]{1}");
    	    Matcher matcher=p.matcher(playerId);
    	    if(matcher.matches())
    	    {
    	        return true;
    	    }
    	    return false;
    	    
    	}
    	
    

}
