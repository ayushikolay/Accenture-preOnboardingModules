package com.sbcc.main;
import com.sbcc.model.Player;
import com.sbcc.model.Batsman;
import com.sbcc.model.Bowler;
import java.util.Scanner;
import java.util.*;
import com.sbcc.utility.SBCCUtility;
import com.sbcc.exception.InvalidPlayerIdException;

import com.sbcc.skeletonvalidator.SkeletonValidator;

public class UserInterface {

	public static void main(String[] args) {
		

		SkeletonValidator validator = new SkeletonValidator();

		Scanner sc = new Scanner(System.in);

		SBCCUtility sb=new SBCCUtility();
		
		do 
		{
		    
		System.out.println("1. Validate player details");
		System.out.println("2. Create Batsman or Bowler");
		System.out.println("3. Validation with InvalidPlayerIdException");
		System.out.println("4. Exit");
		
		System.out.println("Enter your choice");
		int c=sc.nextInt();
		sc.nextLine();
		
		
		if(c == 1)
		{
		    Player p=null;
		      System.out.println("Enter the player details");
		       String dd=sc.nextLine();
		       
		      p=sb.parsePlayerDetails(dd);
		      if(p == null)
		      {
		          System.out.println("Please provide a valid record");
		          continue;
		      }
		      
		      System.out.println("Player id: "+p.getPlayerId());
		      System.out.println("Player name: "+p.getPlayerName());
		      System.out.println("No. of matches played: "+p.getMatchesPlayed());
		      System.out.println("Total runs scored: "+p.getRunScored());
		      System.out.println("Playing zone: "+p.getPlayingZone());
		      
		            
		}
		
		else if(c==2 || c==3)
		{
		    System.out.println("Enter the player details");
		    String str=sc.nextLine();
		    String[] b=str.split(":");
		    
		    Player p=sb.parsePlayerDetails(str);
		    if(p==null)
		    {
		        System.out.println("Please provide a valid record");
		        continue;
		    }
		 
		    System.out.println("Player id: "+p.getPlayerId());
		    System.out.println("Player name: "+p.getPlayerName());
		    System.out.println("No. of matches played: "+p.getMatchesPlayed());
		    System.out.println("Total runs scored: "+p.getRunScored());
		    System.out.println("Playing zone: "+p.getPlayingZone());
		    
		    if(p instanceof Batsman)
		   {
		    System.out.println("Number of Hundreds: "+((Batsman)p).getNoOfHundreds());
		    System.out.println("Number of Fifties: "+((Batsman)p).getNoOfFifties());
		    System.out.println("Star Rating: "+((Batsman)p).getStarRating());
		    
		    }
		    else if(p instanceof Bowler)
		    { 
		      
		        System.out.println("Number of Maidens: "+((Bowler)p).getNoOfMaiden());
		        System.out.println("Number of Hattricks: "+((Bowler)p).getNoOfHattrick());
		        System.out.println("Star Rating: "+((Bowler)p).getStarRating());
		        
		   
		    }
		    
		}


		else 
		{
		    System.out.println("Thank you for using SBCC application");
		    return;
		}
		  

		}while(true);

		
		}
	}


