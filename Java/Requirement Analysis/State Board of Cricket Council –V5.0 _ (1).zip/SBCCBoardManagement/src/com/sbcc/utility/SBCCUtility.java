package com.sbcc.utility;
import java.util.regex.*;
import com.sbcc.model.Player;
import com.sbcc.model.Batsman;
import com.sbcc.model.Bowler;
import com.sbcc.exception.InvalidPlayerIdException;

public class SBCCUtility {
	
	// Include the logic of parsePlayerDetails method as specified in the requirement document - 2
    	public Player parsePlayerDetails(String playerDetails) 
    	{
    	    String[] s=playerDetails.split(":");
    	    
    	    String playerId=s[0];
    	    
    	   // if(!validatePlayerId(playerId))
    	   // {
    	   //    // Player p=new Player();
    	   //    // p.setPlayerId(playerId);
    	   //     return null;
    	   // }
    	   
    	   boolean res=false;
    	   
    	   try 
    	   {
    	       res=validatePlayerId(playerId);
    	   }
    	   catch(InvalidPlayerIdException e)
    	   {
    	       System.out.println(e.getMessage());
    	   }
    	   
    	   if(res)
    	   {
    	       
    	    int len=s.length;
    	    if(s[len-3].equals("Batsman"))
    	    {
    	    
    	   Batsman p=new Batsman();
    	    p.setPlayerId(playerId);
    	    
    	    String playerName=s[1];
    	   p.setPlayerName(playerName);
    	    
    	    int matchesPlayed=Integer.parseInt(s[2]);
    	   p.setMatchesPlayed(matchesPlayed);
    	    
    	    String securedRuns[]=new String[matchesPlayed];
    	    
    	    for(int i=0;i<matchesPlayed;i++)
    	    {
    	        securedRuns[i]=s[3+i];
    	    }
    	    
    	    int total=p.calculateTotalRuns(securedRuns);
    	    
    	    p.setRunScored(total);
    	   
    	    String playingZone=s[3+matchesPlayed];
    	    p.setPlayingZone(playingZone);
    	   
    	   int noOfHundreds=Integer.parseInt(s[len-2]);
    	   int noOfFifties=Integer.parseInt(s[len-1]);
    	   p.setNoOfHundreds(noOfHundreds);
    	   p.setNoOfFifties(noOfFifties);
    	   p.findStarRating();
    	  
    	   return p;
    	        
    	    }
    	    else 
    	    {
    	        Bowler b=new Bowler();
    	       // String playerId=s[0];
    	        b.setPlayerId(playerId);
    	        
    	        String playerName=s[1];
    	        b.setPlayerName(playerName);
    	        
    	        int matchesPlayed=Integer.parseInt(s[2]);
    	        b.setMatchesPlayed(matchesPlayed);
    	        
    	        String securedRuns[]=new String[matchesPlayed];
    	        
    	        for(int i=0;i<matchesPlayed;i++)
    	        {
    	            securedRuns[i]=s[3+i];
    	        }
    	        
    	        int total=b.calculateTotalRuns(securedRuns);
    	        b.setRunScored(total);
    	        b.setPlayingZone(s[3+matchesPlayed]);
    	        
    	        int noOfMaiden=Integer.parseInt(s[len-2]);
    	        int noOfHattrick=Integer.parseInt(s[len-1]);
    	        
    	        b.setNoOfMaiden(noOfMaiden);
    	        b.setNoOfHattrick(noOfHattrick);
    	        b.findStarRating();
    	        return b;
    	    }
    	   }
    	   
    	   return null;
    	   
    	}
    	
    	
    	public boolean validatePlayerId(String playerId) throws InvalidPlayerIdException
    	{
    	    
    	    Pattern p=Pattern.compile("[A-Z]{4}[0-9]{4}[A-Z]{1}");
    	    Matcher matcher=p.matcher(playerId);
    	    if(matcher.matches())
    	    {
    	        return true;
    	    }
    	   
    	   else
    	   throw new InvalidPlayerIdException("Player with Id "+playerId+" is not valid"); 
    	  
    	   
    	}
    	
    

}
