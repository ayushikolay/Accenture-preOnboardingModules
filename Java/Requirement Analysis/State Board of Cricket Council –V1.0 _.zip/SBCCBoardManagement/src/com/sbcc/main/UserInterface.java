package com.sbcc.main;
import com.sbcc.model.Player;
import java.util.Scanner;
import java.util.*;

import com.sbcc.skeletonvalidator.SkeletonValidator;

public class UserInterface {

	public static void main(String[] args) {
		// CODE SKELETON - VALIDATION STARTS
		// DO NOT CHANGE THIS CODE

		SkeletonValidator validator = new SkeletonValidator();

		// CODE SKELETON - VALIDATION ENDS

		// Please start your code from here
		Scanner sc = new Scanner(System.in);
		Player p=null;
		
		do 
		{
		System.out.println("1. Create player");
		System.out.println("2. Display player details");
		System.out.println("3. Exit");
		
		System.out.println("Enter your choice");
		int c=sc.nextInt();
		sc.nextLine();
		
		//Player p=null;
		if(c == 1)
		{
		           System.out.println("Enter the player Id");
		            String id=sc.nextLine();
		            
		            System.out.println("Enter the player name");
		            String name=sc.nextLine();
		            
		            System.out.println("Enter the number of matches played");
		            int n=sc.nextInt();
		            
		            System.out.println("Enter the total runs scored");
		            int runs=sc.nextInt();
		            sc.nextLine();
		            
		            System.out.println("Enter the playing zone");
		            String zone=sc.nextLine();
		            
		            
		            p=new Player(id,name,n,runs,zone);
		           
		            
		}
		else if(c==2)
		{
		    
		    System.out.println("Player id: "+p.getPlayerId());
		    System.out.println("Player name: "+p.getPlayerName());
		    System.out.println("Matches played: "+p.getMatchesPlayed());
		    System.out.println("Total runs scored: "+p.getRunScored());
		    System.out.println("Playing zone: "+p.getPlayingZone());
		    
		}
		else 
		{
		    System.out.println("Thank you for using SBCC application");
		    return;
		}

		}while(true);
	}

}
