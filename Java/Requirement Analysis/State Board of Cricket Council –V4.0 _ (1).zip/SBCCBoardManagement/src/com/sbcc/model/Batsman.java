package com.sbcc.model;
import com.sbcc.model.Player;

/*The class and methods should be declared as public 
and all the attributes should be declared as private.*/
public class Batsman extends Player{
	
	// Include all attributes, getters, setters and constructors as specified in the requirement document - 1
	
	private int noOfHundreds;
	private int noOfFifties;
	private double starRating;
	
	public Batsman()
	{
	    
	}
	
	public Batsman(String playerId, String playerName, int matchesPlayed,int runScored,String playingZone, int noOfHundreds,int noOfFifties)
	{
	    super(playerId,playerName,matchesPlayed,runScored,playingZone);
	    this.noOfHundreds=noOfHundreds;
	    this.noOfFifties=noOfFifties;
	}
	// Fill the logic of findStarRating as specified in the requirement document - 4
	
	public void setNoOfHundreds(int noOfHundreds)
	{
	    this.noOfHundreds=noOfHundreds;
	}
	
	public int getNoOfHundreds()
	{
	    return this.noOfHundreds;
	}
	
	public void setNoOfFifties(int noOfFifties)
	{
	    this.noOfFifties=noOfFifties;
	}
	
	public int getNoOfFifties()
	{
	    return this.noOfFifties;
	}
	
	public void setStarRating(double starRating)
	{
	    this.starRating=starRating;
	}
	
	public double getStarRating()
	{
	    return this.starRating;
	}
	
	public void findStarRating()
	{
	    double rate=((getNoOfHundreds()*10.0)+(getNoOfFifties()*5.0))*getMatchesPlayed()/100;
	    setStarRating(rate);
	    
	}
	


}
