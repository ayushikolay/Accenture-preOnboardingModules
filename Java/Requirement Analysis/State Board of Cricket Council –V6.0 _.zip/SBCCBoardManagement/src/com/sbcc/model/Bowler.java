package com.sbcc.model;
import com.sbcc.model.Player;

/*The class and methods should be declared as public 
and all the attributes should be declared as private.*/
public class Bowler extends Player{
	
	// Include all attributes, getters, setters and constructors as specified in the requirement document - 1
	private int noOfMaiden;
	private int noOfHattrick;
	double starRating;
	
	public Bowler()
	{
	    
	}
	
	public Bowler(String playerId, String playerName, int matchesPlayed, int runScored, String playingZone, int noOfMaiden,int noOfHattrick)
	{
	    super(playerId,playerName,matchesPlayed,runScored,playingZone);
	    this.noOfMaiden=noOfMaiden;
	    this.noOfHattrick=noOfHattrick;
	    
	}
	
	public void setNoOfMaiden(int noOfMaiden)
	{
	    this.noOfMaiden=noOfMaiden;
	}
	
	public int getNoOfMaiden()
	{
	    return this.noOfMaiden;
	}
	
	public void setNoOfHattrick(int noOfHattrick)
	{
	    this.noOfHattrick=noOfHattrick;
	}
	
	public int getNoOfHattrick()
	{
	    return this.noOfHattrick;
	}
	
	public void setStarRating(double starRating)
	{
	    this.starRating=starRating;
	}
	
	public double getStarRating()
	{
	    return this.starRating;
	}
	// Fill the logic of findStarRating as specified in the requirement document - 4
	
	public void findStarRating()
	{
	    double rate=((noOfMaiden*5.0)+(noOfHattrick*10.0))*getMatchesPlayed()/100;
	    setStarRating(rate);
	    
	}
	
	

}
