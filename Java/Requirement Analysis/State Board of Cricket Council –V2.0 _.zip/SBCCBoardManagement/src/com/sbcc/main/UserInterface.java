package com.sbcc.main;
import com.sbcc.model.Player;
import java.util.Scanner;
import java.util.*;
import com.sbcc.utility.SBCCUtility;

import com.sbcc.skeletonvalidator.SkeletonValidator;

public class UserInterface {

	public static void main(String[] args) {
		// CODE SKELETON - VALIDATION STARTS
		// DO NOT CHANGE THIS CODE

		SkeletonValidator validator = new SkeletonValidator();

		// CODE SKELETON - VALIDATION ENDS

		// Please start your code from here
		Scanner sc = new Scanner(System.in);
		Player p=null;
		SBCCUtility sb=new SBCCUtility();
		
		do 
		{
		System.out.println("1. Parse the player details and create player");
		//System.out.println("2. Display player details");
		System.out.println("2. Exit");
		
		System.out.println("Enter your choice");
		int c=sc.nextInt();
		sc.nextLine();
		
		//Player p=null;
		if(c == 1)
		{
		      System.out.println("Enter the player details");
		       String dd=sc.nextLine();
		      p=sb.parsePlayerDetails(dd);
		      
		      System.out.println("Player id: "+p.getPlayerId());
		      System.out.println("Player name: "+p.getPlayerName());
		      System.out.println("Matches played: "+p.getMatchesPlayed());
		      System.out.println("Total runs scored: "+p.getRunScored());
		      System.out.println("Playing zone: "+p.getPlayingZone());
		      
		            
		}
// 		else if(c==2)
// 		{
		    
// 		    System.out.println("Player id: "+p.getPlayerId());
// 		    System.out.println("Player name: "+p.getPlayerName());
// 		    System.out.println("Matches played: "+p.getMatchesPlayed());
// 		    System.out.println("Total runs scored: "+p.getRunScored());
// 		    System.out.println("Playing zone: "+p.getPlayingZone());
		    
// 		}
		else 
		{
		    System.out.println("Thank you for using SBCC application");
		    return;
		}

		}while(true);
	}

}
