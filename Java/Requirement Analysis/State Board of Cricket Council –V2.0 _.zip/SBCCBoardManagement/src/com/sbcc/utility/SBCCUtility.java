package com.sbcc.utility;

import com.sbcc.model.Player;

public class SBCCUtility {
	
	// Include the logic of parsePlayerDetails method as specified in the requirement document - 2
    	public Player parsePlayerDetails(String playerDetails)
    	{
    	    Player p=new Player();
    	    String[] s=playerDetails.split(":");
    	    
    	    String playerId=s[0];
    	    p.setPlayerId(playerId);
    	    
    	    String playerName=s[1];
    	    p.setPlayerName(playerName);
    	    
    	    int matchesPlayed=Integer.parseInt(s[2]);
    	    p.setMatchesPlayed(matchesPlayed);
    	    
    	    String securedRuns[]=new String[matchesPlayed];
    	    
    	    for(int i=0;i<matchesPlayed;i++)
    	    {
    	        securedRuns[i]=s[3+i];
    	    }
    	    
    	    int total=p.calculateTotalRuns(securedRuns);
    	    
    	    p.setRunScored(total);
    	    
    	    p.setPlayingZone(s[3+matchesPlayed]);
    	    
    	    return p;
    	    
    	    
    	}
    	
    // 	public static void main (String[] args) {
    	    
    // 	    System.out.println("1.Parse the player details and create player");
    // 	    System.out.println("2.Exit");
    	    
    // 	    System.out.println("Enter your choice");
    	    
    // 	    Scanner sc=new Scanner(System.in);
    // 	    int ch=sc.nextInt();
    	    
    // 	    Player p=null;
    	    
    // 	    do 
    // 	    {
    // 	        if(ch ==1)
    // 	        {
    // 	            System.out.println("Enter the player details");
    // 	            String str=sc.nextLine();
    	            
    // 	            p=parsePlayerDetails(str);
    	            
    // 	           
    // 	          System.out.println("Player id: "+p.getPlayerId());
    // 	          System.out.println("Player name: "+p.getPlayerName());
    // 	          System.out.println("Matches played: "+p.getMatchesPlayed());
    // 	          System.out.println("Total runs scored: "+p.getRunScored());
    // 	          System.out.println("Playing zone: "+p.getPlayingZone());
    	            
    // 	        }
    	        
    // 	        else 
    // 	        {
    // 	            System.out.println("")
    // 	        }
    	        
    	        
    // 	    }
    	    
    	    
    //	}

}
